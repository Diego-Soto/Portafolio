﻿using System;

namespace LAB11_DASA_1187921
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] seccion1 = new double[5];
            double[] seccion2 = new double[5];
            double suma = 0;
            double suma2 = 0;
            double suma3 = 0;
            double suma4 = 0;
            double promedio = 0;
            double promedio2 = 0;
            double promedio3 = 0;
            double porciento = 0.00;
            double porciento2 = 0.00;
            double porciento3 = 0.00;
            double porciento4 = 0.00;
            double porciento5 = 0.00;
            double porciento6 = 0.00;
            int aprobados = 0;
            int desaprobados = 0;
            int aprobados2 = 0;
            int desaprobados2 = 0;
            int encima90 = 0;
            int debajo75 = 0;
            int encima90b = 0;
            int debajo75b = 0;

            Console.WriteLine("ingrese la nota de cada alumno de la seccion 1");
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("ingrese la nota del estudiante " );
                seccion1[i] = double.Parse(Console.ReadLine());
                
                if (seccion1[i]>=65)
                {
                    aprobados ++;
                }
                else
                {
                    desaprobados++;
                }
                if (seccion1[i]>90)
                {
                    encima90++;
                }
                if (seccion1[i] < 75)
                {
                    debajo75++;
                }
            }
                           porciento = Convert.ToDouble(aprobados * 100 / seccion1.Length);
                           porciento2 = Convert.ToDouble(desaprobados * 100 / seccion1.Length);


            Console.WriteLine("el porciento de aprobados es: " + porciento);
            Console.WriteLine("el porciento de desaprobados es: " + porciento2);
            Console.WriteLine("");
            Console.WriteLine("ingrese la nota de cada alumno de la seccion 2");
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("ingrese la nota del estudiante ");
                seccion2[i] = double.Parse(Console.ReadLine());
                if (seccion2[i] >= 65)
                {
                    aprobados2++;
                }
                else
                {
                    desaprobados2++;
                }
                if (seccion1[i] < 90)
                {
                    encima90++;
                }
                if (seccion1[i] < 75)
                {
                    debajo75b++;
                }
            }
         
            porciento3 = Convert.ToDouble(aprobados2) * 100 / seccion2.Length ;
            porciento4 = Convert.ToDouble(desaprobados2 * 100 / seccion2.Length);

            Console.WriteLine("el porciento de aprobados es: " + porciento3);
            Console.WriteLine("el porciento de desaprobados es: " + porciento4);
            Console.WriteLine("");

            porciento5 = Convert.ToDouble((aprobados + aprobados2) * 100 )/ (seccion2.Length + seccion1.Length);
            porciento6 = Convert.ToDouble((desaprobados + desaprobados2) * 100 )/ (seccion2.Length + seccion1.Length);
            Console.WriteLine("");
            Console.WriteLine("el porciento de aprobados en las dos secciones es: " + porciento5);
            Console.WriteLine("el porciento de desaprobados en las dos secciones es: " + porciento6);
            
                for (int i = 0; i < 5; i++)
                {
                suma =suma+ seccion1[i];
                suma2 = suma+seccion2[i];
                }
            
                suma3 = encima90 + encima90b;
                suma4 = debajo75 + debajo75b;
            
            promedio = suma / seccion1.Length;
            promedio2 = suma2 / seccion2.Length;
            promedio3 = (suma+suma2) / (seccion1.Length + seccion2.Length);
            Console.WriteLine("el promedio de notas de la seccion 1 es : "+promedio);
            Console.WriteLine("el promedio de notas de la seccion 2 es : " + promedio2);
            Console.WriteLine("el promedio de notas de las dos secciones es  : " + promedio3);
            Console.WriteLine("");
            Console.WriteLine("la cantidad de estudiantes que estan por encima de 90 son: " + suma3);
            Console.WriteLine("la cantidad de estudiantes que estan por debajo de 75 son: " + suma4);
        }
    }
}
