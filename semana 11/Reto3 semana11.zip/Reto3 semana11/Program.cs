﻿using System;

namespace Reto2_semana11
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] nivelesA = new int[5];
            int[] nivelesN = new int[5];
            string[] nivelesR = new string[5];
            string responsable="";
            int suma = 0;
            int suma2 = 0;
            int suma3 = 0;
            int mayor, nivel=1;
            int contador = 1;
            int contador2 = 1;
            int contador3 = 1;
            int contador4 = 1;

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("ingrese la cantidad de adultos en el nivel "+ contador);
                nivelesA[i] = int.Parse(Console.ReadLine());
                contador++;
            }
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("ingrese la cantidad de niños en el nivel " + contador2);
                nivelesN[i] = int.Parse(Console.ReadLine());
                contador2++;
            }
            for (int  i = 0;  i<5;  i++)
            {
                Console.WriteLine("ingrese el nombre del responsable en el nivel " + contador3);
                nivelesR[i] = Console.ReadLine();
                contador3++;
            }
            for (int i = 0; i < 5; i++)
            {
                if (nivelesN[0] > nivelesN[1] && nivelesN[0] > nivelesN[2] && nivelesN[0] > nivelesN[3] && nivelesN[0] > nivelesN[4])
                {
                    mayor = nivelesN[0];
                    responsable = Convert.ToString(nivelesR[0]);
                }
                else if (nivelesN[1] > nivelesN[0] && nivelesN[1] > nivelesN[2] && nivelesN[1] > nivelesN[3] && nivelesN[1] > nivelesN[4])
                {
                    mayor = nivelesN[1];
                    responsable = Convert.ToString(nivelesR[1]);
                }
                else if (nivelesN[2] > nivelesN[0] && nivelesN[2] > nivelesN[1] && nivelesN[2] > nivelesN[3] && nivelesN[2] > nivelesN[4])
                {
                    mayor = nivelesN[2];
                    responsable = Convert.ToString(nivelesR[2]);
                }
                else if (nivelesN[3] > nivelesN[0] && nivelesN[3] > nivelesN[1] && nivelesN[3] > nivelesN[2] && nivelesN[3] > nivelesN[4])
                {
                    mayor = nivelesN[3];
                    responsable = Convert.ToString(nivelesR[3]);
                }
                else if (nivelesN[4] > nivelesN[0] && nivelesN[4] > nivelesN[1] && nivelesN[4] > nivelesN[2] && nivelesN[4] > nivelesN[3])
                {
                    mayor = nivelesN[4];
                    responsable = Convert.ToString(nivelesR[4]);
                }
                else
                {
                    mayor = 0;
                }

                
                
            }
            for (int j = 0; j < 5; j++)
            {
                suma += nivelesA[j];
            }
            for (int j = 0; j < 5; j++)
            {
                suma2 += nivelesN[j];
            }
            for (int j = 0; j < 5; j++)
            {
                suma3 = nivelesA[j] + nivelesN[j];
                Console.WriteLine("la suma de las personas en el nivel " + contador4 + " es de:" + suma3);
                contador4++;
            }
            Console.WriteLine("la suma de los adultos en el edificio es: " + suma);
            Console.WriteLine("la suma de los niños en el edificio es: " + suma2);
            Console.WriteLine("el responsable con mas niños es: " + responsable);
        }
    }
}
