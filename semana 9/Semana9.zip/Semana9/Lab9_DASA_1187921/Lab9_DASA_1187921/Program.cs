﻿using System;

namespace Lab9_DASA_1187921
{
    class Program
    {
        static void Main(string[] args)
        {

            int modelo = 0;
            double precio = 0.00;
            string marca = "";
            bool disponible = false;
            double Cambiodolar = 7.50;
            double descuentoaAplicado = 0.00;

            Console.WriteLine("Ingrese el modelo");
            modelo = Convert.ToInt16(Console.ReadLine());

            Console.WriteLine("Ingrese el Precio");
            precio = Convert.ToInt16(Console.ReadLine());

            Console.WriteLine("Ingrese la marca");
            marca = (Console.ReadLine());

            Console.WriteLine("Ingrese el descuento aplicado");
            descuentoaAplicado = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la disponibilidad");
            string disponi = Console.ReadLine();


            if (disponi == "si")
            {
                disponible = true;
            }
            if (disponi == "No")
            {
                disponible = false;
            }
            Console.WriteLine("");
            double precioB = precio / Cambiodolar;
            double descuentoaAplicadoB = precio - descuentoaAplicado;
            double descuentoB = descuentoaAplicado / Cambiodolar;
            double Precioc = precioB - descuentoaAplicado / Cambiodolar;

            //resultado(precio, cambiodolar, disponible, modelo, marca, descuentoaAplicado)
            // static void resultado(double precio, double cambiodolar, bool disponible, int modelo, string marca, double descuentoAplicado);
            Console.WriteLine("modelo: " + modelo);
            Console.WriteLine("marca: " + marca);
            Console.WriteLine("modelo: " + modelo);
            Console.WriteLine("el precio del carro es: " + precio);
            Console.WriteLine("el precio del carro en dolares es: " + "$" + precioB);
            Console.WriteLine("el precio con descuento es: " + descuentoaAplicadoB);
            Console.WriteLine("el precio con descuneto del carro en dolares es: " + "$" + Precioc);
        }
    }
}


