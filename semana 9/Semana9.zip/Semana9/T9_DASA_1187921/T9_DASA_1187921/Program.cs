﻿using System;

namespace T9_DASA_1187921
{
    class Program
    {
        static void Main(string[] args)
        {
            int modelo = 0;
            double precio = 0;
            string marca = "";
            double Iva = 0.12;
            double Ivatotal = 0;
            double IvaB = 0;
            Console.WriteLine("Ingrese el modelo: ");
            modelo = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese el precio: ");
            precio = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la marca: ");
            marca = Console.ReadLine();
            Console.WriteLine("");
            resultado(precio, modelo, marca, Iva, Ivatotal, IvaB);
        }

        public static void resultado(double precio, int modelo, string marca, double Iva, double Ivatotal, double IvaB)
        {

            Ivatotal = precio + (precio * Iva);

            double Ivac = Iva * precio;


            Console.WriteLine("Modelo: " + modelo);
            Console.WriteLine("Marca: " + marca);
            Console.WriteLine("El precio sin IVA en quetzales es: " + precio);
            Console.WriteLine("El precio con IVA en quetzales es " + Ivatotal);
            Console.WriteLine("El monto del IVA en quetzales es: " + Ivac);
        }
    }
}
