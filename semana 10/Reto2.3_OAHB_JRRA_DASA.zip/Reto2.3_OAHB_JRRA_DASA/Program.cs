﻿using System;

namespace Reto2._3_OAHB_JRRA_DASA
{
    class Program
    {
        static void Main(string[] args)
        {
            double precio = 0;
            string tipoHelado;
            int topping = 0;
            Console.WriteLine("ingrese su sabor de helado");
            tipoHelado = Console.ReadLine();
            Console.WriteLine("Ingrese la cantidad de toppings que desea");
            topping = int.Parse(Console.ReadLine());
            if (tipoHelado == "chocolate" || tipoHelado == "vainilla" || tipoHelado == "fresa")
            {
                precio = 5;
            }
            else if (tipoHelado == "napolitano" || tipoHelado == "pistacho")
            {
                precio = 7;
            }
            switch (topping)
            {
                case 1:
                    precio = precio + 1;
                    break;

                case 2:
                    precio = precio + 2;
                    break;

                case 3:
                    precio = precio + 1;
                    break;
            }
            Console.WriteLine("Su total a pagar es de: " + precio);
            Console.ReadKey();
        }
        /* public static double CalcularPrecio(string tipoHelado, int topping)
         {
             return precio;
         }
        */
    }
}
