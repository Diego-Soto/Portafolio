﻿using System;

namespace L10_DASA_1187921
{
    class Program
    {
        static void Main(string[] args)
        { 
           
       
            int i = 0;
            while (i<3)
            {
                Console.WriteLine("ingrese el usuario");
                string usuario = Console.ReadLine();
                Console.WriteLine("ingrese contraseña");
                string contrasena = Console.ReadLine();
                bool x;
                x = Login(contrasena, usuario);
                if (x==true)
                {
                    i = 3;
                    Console.WriteLine("sesion iniciada");
                }
                else
                {
                    i++;
                }
                if (i < 3)
                {
                    Console.WriteLine("usuario o contraseña incorrecta, intente de nuevo");
                }
                Console.ReadKey();
            }
 
        }
        static bool Login(string contrasena, string usuario)
        {
            
            
            if (usuario == "usuario1" && contrasena == "asdasd")
            {

                return true;

            }
            else
            {
                return false;
            }
        }
        
        
        
    }
}
