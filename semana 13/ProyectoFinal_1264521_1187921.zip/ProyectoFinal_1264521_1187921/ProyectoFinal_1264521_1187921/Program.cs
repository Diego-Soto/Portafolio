﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto
{
    class Program
    {
        static void Main(string[] args)
        {
            bool[,] contador = new bool[4, 2]; //Lleva el control de las habitaciones a las que se les ha configurado la ventilación y calefacción
            Random random = new Random(); //Genera números aleatorios
            DateTime horario = new DateTime(); //Para almacenar datos en formato hora
            int[] tempMin = { 0, 0, 0, 0 }; //Almacena las temperaturas mínimas por habitación
            int[] tempMax = { 0, 0, 0, 0 }; //Almacena las temperaturas máximas por habitación
            double[] promTemps = { 0.0, 0.0, 0.0, 0.0 }; //Almacena el promedio de la temperatura máxima y mínima por habitación
            int[,] Humedad = new int[4, 24]; //Almacena los porcentajes de humedad de un día por habitación
            string[,] habitaciones = new string[4, 3]; //Almacena las configuraciones de cada habitación

            //Porcentaje de humedad durante el día
            for (int a = 0; a < 4; a++)
            {
                for (int b = 0; b < 24; b++)
                    Humedad[a, b] = random.Next(15, 100);
            }

            void Menú()
            {
            menú:
                try
                {
                    Console.Clear();
                    Console.WriteLine("MENÚ PRINCIPAL\n");
                    Console.WriteLine("1. Prueba del sistema de ventilación");
                    Console.WriteLine("2. Prueba del sistema de calefacción");
                    Console.WriteLine("3. Prueba del sistema de iluminación");
                    Console.WriteLine("4. Panel de control");
                    Console.WriteLine("5. Salir del programa");
                    Console.Write("\nSeleccione una opción: ");
                    int opción = int.Parse(Console.ReadLine());
                    switch (opción)
                    {
                        case 1: //En caso de querer probar el funcionamiento del sistema de ventilación
                            Ventilación();
                            goto menú;

                        case 2: //En caso de querer probar el sistema de calefacción
                            Calefacción();
                            goto menú;

                        case 3: //En caso de querer probar el sistema de iluminación
                            Iluminación();
                            goto menú;

                        case 4:
                        panel:
                            try
                            {
                                Console.Clear();
                                Console.WriteLine("PANEL DE CONTROL\n");
                                Console.WriteLine("1. Programar sistema de ventilación");
                                Console.WriteLine("2. Configurar temperaturas máximas y mínimas");
                                Console.WriteLine("3. Promedio de las temperaturas máximas y mínimas");
                                Console.WriteLine("4. Regresar al menú principal");
                                Console.Write("\nEscoja la opción que desea realizar: ");
                                int op = int.Parse(Console.ReadLine());
                                switch (op)
                                {
                                    case 1: //Se establece los horarios de encendido de la ventilación para cada habitación
                                        int cont = 0;
                                    config1:
                                        Console.Clear();
                                        Console.WriteLine("PROGRAMACIÓN DEL SISTEMA DE VENTILACIÓN\n");
                                        Console.Write("Habitación que desea programar (1 - 4): ");
                                        int hab1 = int.Parse(Console.ReadLine()) - 1;
                                        if (!SelecHab(hab1)) //Verifica que la habitación seleccionada sea válida
                                            goto config1;

                                        if (!ReConfig(hab1, 0)) //Verifica si la habitación ya ha sido configurada
                                            goto panel;

                                        Console.WriteLine("Porcentajes de humedad a cada hora para la habitación " + hab1 + " el " + DateTime.Now.Date + " según el informa del clima:\n");
                                        for (int a = 0; a < 12; a++) //Imprime los porcentajes de humedad para diferentes horas del día
                                        {
                                            Console.WriteLine("     " + a + ":00 hrs - " + Humedad[hab1, a] + "%" + "\t     " + (a + 12) + ":00 hrs - " + Humedad[hab1, (a + 12)] + "%");
                                        }
                                        Console.WriteLine("\nHORARIO(S).\nNOTA: Ingresar horario en formato DE 24 hrs - (00:00).");

                                    //Se configuran disintos horarios de encendido para la ventilación
                                    configurar:
                                        cont++;
                                        Console.Write("Configure horario de encendido " + cont + ": ");
                                        horario = DateTime.Parse(Console.ReadLine());
                                        habitaciones[hab1, 0] += horario.ToString() + " hrs\n";
                                    preguntar:
                                        Console.Write("¿Desea configurar otra hora? (Si/No): ");
                                        string resp = Console.ReadLine();
                                        if (resp.ToUpper() == "SI") //Verifica si la respuesta del usuario es "si"
                                        {
                                            Console.WriteLine();
                                            goto configurar;
                                        }
                                        else if (resp.ToUpper() != "NO") //Verifica si el usuario responde algo no válido
                                        {
                                            Console.WriteLine("\nLa respuesta no es válida.");
                                            goto preguntar;
                                        }
                                        contador[hab1, 0] = true;
                                        Console.WriteLine("\n¡Horario(s) para la habitación " + (hab1 + 1) + " configurado(s)!");
                                        Console.ReadKey();

                                        goto panel;

                                    case 2: //Se establecen las temperaturas máximas y mínimas de las habitaciones
                                        int hab2 = 0;
                                    config2:
                                        Console.Clear();
                                        Console.WriteLine("CONFIGURACIÓN DE TEMPERATURAS MÁXIMAS Y MÍNIMAS\n");
                                        if (hab2 == 0) //Verifica si ya se ha seleccionado una habitación
                                        {
                                            Console.Write("Habitación que desea programar (1 - 4): ");
                                            hab2 = int.Parse(Console.ReadLine()) - 1;
                                            if (!SelecHab(hab2 + 1)) //Verifica que la habitación seleccionada sea válida
                                                goto config2;

                                            if (!ReConfig(hab2, 1)) //Verifica si la habitación ya ha sido configurada
                                                goto panel;
                                        }
                                        else
                                            Console.WriteLine("Habitación que desea programar (1 - 4): " + hab2);

                                        //Configuración de la temperatura mínima
                                        if (tempMin[hab2] == 0) //Verifica si ya se ha registrado una temperatura mínima para la habitación
                                        {
                                            Console.Write("Configure la temperatura mínima: ");
                                            tempMin[hab2] = int.Parse(Console.ReadLine());
                                            if (tempMin[hab2] < 18 || tempMin[hab2] > 22) //Verifica que la temperatura mínima no este fuera de rango
                                            {
                                                Console.WriteLine("\nLa temperatura no entra en el rango permitido.");
                                                Console.ReadKey();
                                                tempMin[hab2] = 0;
                                                goto config2;
                                            }
                                        }
                                        else
                                            Console.WriteLine("Configure la temperatura mínima: " + tempMin[hab2]);

                                        //Configuración de la temperatura máxima
                                        Console.Write("Configure la temperatura máxima: ");
                                        tempMax[hab2] = int.Parse(Console.ReadLine());
                                        if (tempMax[hab2] < 22 || tempMax[hab2] > 32) //Verifica que la temperatura máxima no este fuera de rango
                                        {
                                            Console.WriteLine("\nLa temperatura no entra en el rango permitido.");
                                            Console.ReadKey();
                                            goto config2;
                                        }

                                        habitaciones[hab2, 1] = tempMin[hab2].ToString() + "°";
                                        habitaciones[hab2, 2] = tempMax[hab2].ToString() + "°";
                                        contador[hab2, 1] = true;
                                        Console.WriteLine("\n¡Temperatura para la habitación " + (hab2 + 1) + " configurada!");
                                        Console.ReadKey();
                                        goto panel;

                                    case 3:


                                        //Verificación de que todas las habitaciones hayan sido configuradas de calefacción
                                        for (int a = 0; a < 4; a++)
                                        {
                                            if (contador[a, 1] == false)
                                            {
                                                Console.WriteLine("\nPara acceder a esta opción primero debe de configurar las temperaturas máximas y mínimas de todas las habitaciones.");
                                                Console.ReadKey();
                                                goto panel;
                                            }
                                        }

                                        //Cálculo del promedio de temperaturas máximas y mínimas por habitación
                                        Console.Clear();
                                        Console.WriteLine("PROMEDIO DE TEMPERATURAS MÁXIMAS Y MÍNIMAS\n");
                                        Console.WriteLine("\t\tTemperaturas máximas\t\tTemperaturas mínimas\t\tPromedio de temperaturas");
                                        for (int a = 0; a < 4; a++) //For para recorrer cada habitación
                                        {
                                            promTemps[a] = (tempMin[a] + tempMax[a]) / 2;
                                            Console.WriteLine("Habitación " + (a + 1) + ": " + "\t\t" + habitaciones[a, 1] + "\t\t\t\t" + habitaciones[a, 2] + "\t\t\t\t   " + Math.Round(promTemps[a], 1) + "°");
                                        }
                                        Console.WriteLine("\nPromedio total de temperatura de la casa: " + Math.Round(((promTemps[0] + promTemps[1] + promTemps[2] + promTemps[3]) / 4), 1));
                                        Console.ReadKey();
                                        goto panel;
                                    case 4:
                                        Console.WriteLine("\n\nRegresando al menú principal...");
                                        Console.ReadKey();
                                        goto menú;

                                    default: //En caso de seleccionar una opción fuera de las brindadas
                                        Console.WriteLine("\nNo seleccionó una opción válida, intente de nuevo. ");
                                        Console.ReadKey();
                                        goto panel;
                                }
                            }
                            catch
                            {
                                Console.WriteLine("\nNo se pudo completar la acción porque ingresó un tipo de dato no válido, intente de nuevo.");
                                Console.ReadKey();
                                goto panel;
                            }


                        case 5: //En caso se desee salir del programa
                            Console.WriteLine("\n\n¡Vuelva pronto!");
                            break;

                        default: //En caso de seleccionar una opción fuera de las brindadas
                            Console.WriteLine("\nNo seleccionó una opción válida, intente de nuevo. ");
                            Console.ReadKey();
                            goto menú;
                    }
                }
                catch //En el caso de que se ingrese un tipo de dato inválido
                {
                    Console.WriteLine("\nNo ingresó un tipo de dato válido, intente de nuevo.");
                    Console.ReadKey();
                    goto menú;
                }
            }


            bool ReConfig(int hab, int index)
            {
                if (contador[hab, index] == true)
                {
                preguntar:
                    Console.Write("Ya se ha configurado esta habitación, ¿desea reescribirla? (Si/No): ");
                    string resp = Console.ReadLine();
                    if (resp.ToUpper() == "SI")
                        return true;
                    else if (resp.ToUpper() != "NO")
                    {
                        Console.WriteLine("\nLa respuesta no es válida.");
                        Console.ReadKey();
                        goto preguntar;
                    }
                    return false;
                }
                return true;
            }

            bool SelecHab(int hab)
            {
                try
                {
                    if (hab < 1 || hab > 4)
                    {
                        Console.WriteLine("\nLa habitación seleccionada no es válida, intente de nuevo.");
                        Console.ReadKey();
                        return false;
                    }
                    return true;
                }
                catch
                {
                    Console.WriteLine("\nLa habitación seleccionada no es válida, intente de nuevo.");
                    Console.ReadKey();
                    return false;
                }

            }

            //Realiza una prueba del funcionamiento de la ventilación
            void Ventilación()
            {
                Console.Clear();
                Console.WriteLine("PRUEBA DE VENTILACIÓN\n");
                Console.Write("Ingrese un porcentaje de humedad: ");
                int humedad = int.Parse(Console.ReadLine());

                //Regula la humedad dependiendo el porcentaje
                if (humedad > 70)
                {
                    Console.WriteLine("\nHumedad por arriba de los niveles permitidos, activando ventilación...");
                    Console.ReadKey();
                    Console.WriteLine("Humedad regulada al 70%.");
                }
                else
                {
                    Console.WriteLine("\nPorcentaje de humedad dentro de los niveles permitidos.");
                }
                Console.ReadKey();
            }

            //Realiza una prueba del funcionamiento de la calefacción
            void Calefacción()
            {
                Console.Clear();
                Console.WriteLine("PRUEBA DE CALEFACCIÓN\n");
                Console.Write("Ingrese la temperatura de la casa: ");
                int temperatura = int.Parse(Console.ReadLine());

                //Verifica la temperatura de la casa/habitación y activa/desactiva los radiadores para regularla
                if (temperatura < 18)
                {
                    Console.WriteLine("\nTemperatura por debajo de los 18°, activando calefacción...");
                    Console.ReadKey();
                    Console.WriteLine("Temperatura regulada a 22°.");
                }
                else if (temperatura > 22)
                {
                    Console.WriteLine("\nTemperatura por arriba de la deseada, apagando radiadores...");
                    Console.ReadKey();
                    Console.WriteLine("Temperatura regulada a 22°.");
                }
                else
                    Console.WriteLine("\nTemperatura de la casa en un nivel deseado.");
                Console.ReadKey();
            }

            //Realiza una prueba del funcionamiento de la iluminación
            void Iluminación()
            {
                Console.Clear();
                Console.WriteLine("PRUEBA DE ILUMINACIÓN\n");
                Console.WriteLine("Activando sensores...");
                Console.ReadKey();
            preguntar:
                Console.Write("\n¿Se encuentra gente dentro de la habitación? (Si/No): ");
                string sensor = Console.ReadLine();

                //Verifica si se encuentra alguien dentro de la habitación
                if (sensor.ToUpper() == "SI")
                {
                    Console.WriteLine("\nEncendiendo luz...");
                    Console.ReadKey();
                    Console.WriteLine("Luz prendida.");
                }
                else if (sensor.ToUpper() != "NO")
                {
                    Console.WriteLine("La respuesta no es válida.");
                    Console.ReadKey();
                    goto preguntar;
                }
                else
                {
                    Console.WriteLine("\nApagando luz...");
                    Console.ReadKey();
                    Console.WriteLine("Luz apagada.");
                }
                Console.ReadKey();
            }

            Menú();
        }
    }
}