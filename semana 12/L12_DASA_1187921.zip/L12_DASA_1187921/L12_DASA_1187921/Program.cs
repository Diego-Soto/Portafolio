﻿using System;

namespace L12_DASA_1187921
{
    class Program
    {
        static void Main(string[] args)
        
        {
            int suma = 0;
            int promedio = 0;
            int[,] matriz = new int[5, 4];
            int[,] matriz2 = new int[5, 4];
            int[,] matriz3 = new int[5, 4];
            Random x = new Random();
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    matriz[i, j] = x.Next(50);
                    matriz2[i, j] = x.Next(50);
                    matriz3[i, j] = matriz2[i, j] + matriz[i, j];
                    Console.Write(matriz3[i, j] + "\t");
                }
                Console.WriteLine();

            }


            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    matriz[i, j] = x.Next(50);
                    suma = suma + matriz[i,j];

                }
            }
            promedio = suma / matriz.Length;

            Console.WriteLine("el promedio de la matriz es: " + promedio);
            Console.ReadKey();
        }
        
    }
}
