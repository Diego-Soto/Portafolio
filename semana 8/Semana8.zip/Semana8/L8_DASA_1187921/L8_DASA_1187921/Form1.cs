﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L8_DASA_1187921
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            int op = comboBox1.SelectedIndex;
            switch (op)
            {
              case 1:
                    tabControl1.SelectTab(op);
                    break;
                case 2:
                    tabControl1.SelectTab(op);
                    break;
                case 3:
                    tabControl1.SelectTab(op);
                    break;
                case 4:
                    tabControl1.SelectTab(op);
                    break;
            }

            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int num = int.Parse(textBox1.Text);
            int x = 1;
            int suma = 0;
            while (num>0)
            {
                suma = suma + x;
                x = x + 1;

            }
            label1.Text = suma.ToString();


        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            int num = int.Parse(textBox3.Text);
            string res = " ";
            for (int i = 1; i <= 10; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    if (j < 10)

                        label2.Text = res += "\t" + Convert.ToString(i * j);

                    else
                        label2.Text = res += Convert.ToString(i * j) + "\n";
                }
            }
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

 

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {
           
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int a = 0;
                int num = int.Parse(textBox4.Text);
                for (int i = 1; i < num; i++)
                {
                    if (num % i == 0)
                        a = a + i;

                }
                if (a == num)

                    label4.Text = "el numero es perfecto";

                else if

                    label4.Text = "el numero  no es perfecto";
            }



            catch (Exception)
            {
                label4.Text = "datos no  validos";
            }
        }
    }
}

